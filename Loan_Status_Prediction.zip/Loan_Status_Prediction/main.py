from flask import Flask, render_template, request
import pandas as pd
import joblib


# load the pre-trained machine learning model
model = joblib.load('model.pkl')
scaler = joblib.load('model.pkl')

# initialize the Flask app
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')


# define the route for the prediction function
@app.route('/predict', methods=['POST'])
def predict():
    # Get user inputs from the form
    loan_limit = float(request.form['loan_limit'])
    gender = request.form['gender']
    approv_in_adv = request.form['approv_in_adv']
    loan_type = request.form['loan_type']
    loan_purpose = request.form['loan_purpose']
    credit_worthiness = request.form['credit_worthiness']
    business_or_commercial = request.form['business_or_commercial']
    loan_amount = float(request.form['loan_amount'])
    upfront_charges = float(request.form['upfront_charges'])
    term = int(request.form['term'])
    neg_ammortization = request.form['neg_ammortization']
    interest_only = request.form['interest_only']
    lump_sum_payment = request.form['lump_sum_payment']
    property_value = float(request.form['property_value'])
    income = float(request.form['income'])
    credit_type = request.form['credit_type']
    credit_score = int(request.form['credit_score'])
    co_applicant_credit_type = request.form['co-applicant_credit_type']
    age = int(request.form['age'])
    submission_of_application = request.form['submission_of_application']
    ltv = float(request.form['ltv'])
    dtir1 = float(request.form['dtir1'])
    region = request.form['region']

    # Scale the features
    input_data = pd.DataFrame({
        'loan_limit': [loan_limit],
        'gender': [gender],
        'approv_in_adv': [approv_in_adv],
        'loan_type': [loan_type],
        'loan_purpose': [loan_purpose],
        'credit_worthiness': [credit_worthiness],
        'business_or_commercial': [business_or_commercial],
        'loan_amount': [loan_amount],
        'upfront_charges': [upfront_charges],
        'term': [term],
        'neg_ammortization': [neg_ammortization],
        'interest_only': [interest_only],
        'lump_sum_payment': [lump_sum_payment],
        'property_value': [property_value],
        'income': [income],
        'credit_type': [credit_type],
        'credit_score': [credit_score],
        'co-applicant_credit_type': [co_applicant_credit_type],
        'age': [age],
        'submission_of_application': [submission_of_application],
        'ltv': [ltv],
        'dtir1':[dtir1],
        'region': [region]
    })

    # Make prediction using the model
    prediction = model.predict(input_data)[0]
    if prediction == 1:
        status = 'Congratulations,You Are  Eligible For a Loan'
    else:
        status = 'Sorry,You Are Not Eligible For a Loan'

    # Render the prediction page with the result
    return render_template('predict.html', status=status)




# run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
